import React from 'react';
import './Equipo5.css';

const App5= () => {
  return (
    <div className="equipo">
        <h1>Deportivo Pasto</h1>
      
        <div 
        className="imgcan">
       <img className="Deportivo Pasto" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSEVQojGdvLcFxRaD1dJKLmNIvcQJ4kP-TXr9gVeifO_Q&s" alt="" />
       </div>

      <div className="informacion">
        <p>El Deportivo Pasto es un club de fútbol profesional colombiano con sede en la ciudad de Pasto, capital del departamento de Nariño. Fue fundado el 14 de abril de 1948 y es uno de los equipos más tradicionales del fútbol colombiano.</p>
        <ul className="palmares">
          <li>Palmarés:</li>
          <li>1 título de Primera A!!</li>
        </ul>
      
        <center><h2>Un recuerdo inolvidable... </h2></center>
        <div className="Estadio">
                <iframe width="689" height="388" src="https://www.youtube.com/embed/pvcJuxr95xo" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> 
                </div>

        <div className="jugadores">
          <center><h2>Jugadores destacados</h2>
          <ul>
            <li>Juan Camilo Chaverra</li>
            <li>Jeison Palacios</li>
            <li>Diego Botero</li>
            <li>Facundo Ospina</li>
            <li>Andrey Estupiñán</li>
          </ul> </center>
        </div>
      </div>
    </div>
  );
}

export {App5};