import { Link } from "react-router-dom";
import './style.home.css';

const Homepage = () => {
  return (
    <div className="containermp">
      <div className="contentmp">
        
<center><h1>Bienvenidos</h1>
        <h2>Esta es la home page</h2>
        <div className="button-group">
          <Link to="/homepage11">
            <button>Empezar 🚀</button>
          </Link>
          <Link to="/Inicio22">
            <button>Barcelona</button>
          </Link>
          <Link to="/Inicio33">
            <button>Manchester United</button>
          </Link>
          <Link to="/Inicio4">
            <button>Bayern Munich</button>
          </Link>
          <Link to="/Equipo55">
            <button>Deportivo Pasto</button>
          </Link>
        </div></center>

      </div>
    </div>
  );
};

export { Homepage }