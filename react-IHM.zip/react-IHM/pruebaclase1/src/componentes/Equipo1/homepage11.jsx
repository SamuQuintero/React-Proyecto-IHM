import React from 'react';
import './homepage1.css';

const App = () => {
  return (
    <div className="equipo">
      <div className="encabezado">
        <h1>Real Madrid</h1>
        <div 
        className="imgcan">
       <img className="Realmadrid" src="https://bolavip.com/__export/1645516242114/sites/bolavip/img/2022/02/22/befunky-collage_-_2022-02-22t083319_282.jpg_1159711837.jpg" alt="" />
       </div>

      </div>
      <div className="informacion">
        <p>
          El Real Madrid Club de Fútbol, comúnmente conocido como Real Madrid, es una
          entidad deportiva polideportiva con sede en Madrid, España. Fue fundado el
          6 de marzo de 1902 y es uno de los clubes más populares y con más éxitos
          del mundo.
        </p>
        <ul className="palmares">
          <h2>Palmarés:</h2>
          <li>36 títulos de Liga</li>
          <li>14 títulos de Copa de Europa/Liga de Campeones</li>
          <li>20 Copas del rey</li>
          <li>13 Supercopas de España</li>
          <li>5 Copas Mundiales de Clubes de la FIFA</li>
        </ul>
        
        <center><h2>Les presentamos nuestro estadio recién renovado!</h2></center>
        <div className="Estadio">
                <iframe width="650" height="400" src="https://www.youtube.com/embed/aBIpPXIFBCs" title="Así &#39;será&#39; el&#39; nuevo&#39; Santiago&#39; Bernabéu&#39;  " frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> 
                </div>

          <div className="jugadores">
          <center>
          <h2>Jugadores destacados</h2>
          <ul>
          <li>Vinícius Júnior</li>
          <li>Jude Bellingham</li>
          <li>Luka Modrić</li>
          <li>Thibaut Courtois</li>
          <li>Tony Kroos</li>
          </ul></center>
        </div>
      </div>
    </div>
  );
};

export { App };
