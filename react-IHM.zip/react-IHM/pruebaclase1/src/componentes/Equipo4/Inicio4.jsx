import React from 'react';
import './Equipo4.css';

const App4= () => {
  return (
    <div className="equipo">
        <h1>FC Bayern München</h1>
      
        <div 
        className="imgcan">
       <img className="Bayern München" src="https://cdn2.mediotiempo.com/uploads/media/2021/11/28/bayern-munich-ha-tenido-varios.jpg" alt="" />
       </div>

      <div className="informacion">
        <p>El FC Bayern München, conocido como Bayern de Múnich o simplemente Bayern, es un club deportivo alemán con sede en la ciudad de Múnich, capital del estado libre de Baviera. Fue fundado el 27 de febrero de 1900 y es uno de los clubes más populares y con más éxitos del mundo.</p>
        <ul className="palmares">
          <li>Palmarés:</li>
          <li>33 títulos de Bundesliga</li>
          <li>6 títulos de Copa de Europa/Liga de Campeones</li>
          <li>20 Copas de Alemania</li>
          <li>11 Súper copas alemanas</li>
          <li>2 Súper copa de la Uefa</li>
          <li>2 Copas Mundiales de Clubes de la FIFA</li>
        </ul>
       
        <center><h2>Un poco "Fuera" de las canchas. </h2></center>
        <div className="Estadio">
                <iframe width="689" height="388" src=" https://www.youtube.com/embed/k54haltoDo8" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> 
                </div>

        <div className="jugadores">
          <center><h2>Jugadores destacados</h2>
          <ul>
            <li>Leroy Sané</li>
            <li>Manuel Neuer</li>
            <li>Joshua Kimmich</li>
            <li>Thomas Müller</li>
            <li>Serge Gnabry</li>
          </ul></center>
        </div>
      </div>
    </div>
  );
}

export {App4};