import React from 'react';
import './inicio2.css';

const App2= () => {
  return (
    <div className="equipo">
        <h1>FC Barcelona</h1>
     
        <div 
        className="imgcan">
       <img className="Barcelona" src="https://images2.minutemediacdn.com/image/upload/c_crop,w_5156,h_2900,x_0,y_214/c_fill,w_1440,ar_16:9,f_auto,q_auto,g_auto/images/GettyImages/mmsport/90min_es_international_web/01fkjy2hw2nkkbkm65mk.jpg" alt="" />
       </div>

      <div className="informacion">
        <p>El FC Barcelona, comúnmente conocido como Barcelona y por sus seguidores como Barça, es un club deportivo polideportivo español con sede en Barcelona, capital de la comunidad autónoma de Cataluña. Fue fundado el 29 de noviembre de 1899 y desde 1928 es miembro de la Confederación Estatal de Deportes de Cataluña.</p>
        <ul className="palmares">
          <li>Palmarés:</li>
          <li>27 títulos de Liga</li>
          <li>5 títulos de Copa de Europa/Liga de Campeones</li>
          <li>31 Copas del rey</li>
          <li>5 Supercopas de Europa</li>
          <li>3 Copas Mundiales de Clubes de la FIFA</li>
        </ul>
        
        <center><h2>Próximamente...</h2></center>
        <div className="Estadio">
                <iframe width="689" height="388" src="https://www.youtube.com/embed/k1SIK8T01OU" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> 
                </div>

        <div className="jugadores">

          <center><h2>Jugadores destacados</h2>
          <ul>
            <li>Pedri</li>
            <li>Gavi</li>
            <li>Lamine Yamal</li>
            <li>Robert Lewandowski</li>
            <li>Ronald Araujo</li>
          </ul> </center>
          
        </div>
      </div>
    </div>
  );
}

export {App2};







