import React from 'react';
import './Inicio3.css';

const App3= () => {
  return (
    <div className="equipo">
        <h1>Manchester United</h1>
      
        <div 
        className="imgcan">
       <img className="Manchester United" src="https://www.sopitas.com/wp-content/uploads/2013/04/mandunited.jpg" alt="" />
       </div>

      <div className="informacion">
        <p>El Manchester United Football Club es un club de fútbol profesional inglés con sede en Old Trafford, Trafford, Gran Mánchester. Fundado como Newton Heath LYR Football Club en 1878, el club cambió su nombre a Manchester United en 1902 y se mudó a Old Trafford en 1910.</p>
        <ul className="palmares">
          <li>Palmarés:</li>
          <li>20 títulos de Liga</li>
          <li>3 títulos de Copa de Europa/Liga de Campeones</li>
          <li>3 Liga de Europa</li>
          <li>1 Supercopas de Europa</li>
          <li>1 Copa Mundial de Clubes de la FIFA</li>
        </ul>
        
        <center><h2>El que no vive para servir no sirve para vivir... </h2></center>
        <div className="Estadio">
                <iframe width="689" height="388" src="https://www.youtube.com/embed/6o9w_XWGuE4" title="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe> 
                </div>


        <div className="jugadores">
          <center><h2>Jugadores destacados</h2>
          <ul>
            <li>Kobby Mainoo</li>
            <li>Alejandro Garnacho</li>
            <li>Bruno Fernandes</li>
            <li>Casemiro</li>
            <li>Marcus Rashford</li>
          </ul></center>
          
        </div>
      </div>
    </div>
  );
}

export {App3};