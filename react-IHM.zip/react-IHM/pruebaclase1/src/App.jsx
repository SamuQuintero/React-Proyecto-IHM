import React from 'react';
import Mainpage from './componentes/mainpage/mainpage';
import { createBrowserRouter, RouterProvider} from 'react-router-dom';
import { Homepage } from './componentes/homepage/homepage';
import {App} from './componentes/Equipo1/homepage11';
import {App2} from './componentes/Equipo2/Inicio22'; 
import {App3} from './componentes/Equipo3/Inicio33'; 
import {App4} from './componentes/Equipo4/Inicio4'; 
import {App5} from './componentes/Equipo5/Equipo55';


const router = createBrowserRouter([
  {
    path: "/",
    element: <Mainpage/>
  },
  {
  path: "home",
  element: <Homepage/>
  },
  {
    path: "homepage11",
    element: <App/>
  },
  {
    path: "inicio22",
    element: <App2/>
  },
  {
    path: "inicio33",
    element: <App3/>
  },
  {
    path: "inicio4",
    element: <App4/>
  },
  {
    path: "Equipo55",
    element: <App5/>
  },
]);

function Appa() {

  return (
    <React.Fragment>
      <RouterProvider router={router} />
    </React.Fragment>
  )
}

export default Appa